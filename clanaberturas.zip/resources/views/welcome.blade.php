<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Clan Aberturas</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>

            img{
                display:block;
                width:100%; height:100%;
                object-fit: cover;
            }
        </style>
    </head>
    <body>
        <img src="img/const.jpg">
    </body>
</html>
